import HomePage from '../pageobjects/home.page'
import BankingPage from '../pageobjects/banking.page'
import HomeLoansPage from '../pageobjects/home.loans.page'
import InsurancePage from '../pageobjects/insurance.page'
import InvestingAndSuperPage from '../pageobjects/investing.and.super.page'
import BusinessPage from '../pageobjects/business.page'
import InstitutionalPage from '../pageobjects/institutional.page'

describe('FEATURE: Checking page header tabs on CommBank website', () => {
  it('should open CommBank Homepage', async () => {
    await HomePage.open()
    await HomePage.checkHeaderAndFooter()
    await expect(HomePage.desktopImage).toBeExisting()
    await expect(browser).toHaveTitle('CommBank - bank accounts, credit cards, home loans and insurance')
  })

  it('should click on Banking tab from the Homepage', async () => {
    await HomePage.openBankingPage()
    await BankingPage.checkHeaderAndFooter()
    await expect(browser).toHaveTitle('Banking - CommBank')
    await expect(browser).toHaveUrlContaining('banking')
    await expect(BankingPage.titleOnPage).toHaveText('Banking')
  })

  it('should click on Home loans tab from the Banking page', async () => {
    await BankingPage.openHomeLoansPage()
    await HomeLoansPage.checkHeaderAndFooter()
    await expect(browser).toHaveTitle('Home loans - calculators, guides and compare - CommBank')
    await expect(browser).toHaveUrlContaining('home-loans')
    await expect(HomeLoansPage.titleOnPage).toHaveText('Home loans')
  })

  it('should click on Insurance tab from the Home loans page', async () => {
    await HomeLoansPage.openInsurancePage()
    await InsurancePage.checkHeaderAndFooter()
    await expect(browser).toHaveTitle('Insurance - CommBank')
    await expect(browser).toHaveUrlContaining('insurance')
    await expect(InsurancePage.titleOnPage).toHaveText('Insurance')
  })

  it('should click on Investing & super tab from the Insurance page', async () => {
    await InsurancePage.openInvestingAndSuperPage()
    await InvestingAndSuperPage.checkHeaderAndFooter()
    await expect(browser).toHaveTitle('Investing & Super - CommBank')
    await expect(browser).toHaveUrlContaining('investing-and-super')
    await expect(InvestingAndSuperPage.titleOnPage).toHaveText('Investing & Super')
  })

  it('should click on Business tab from the Investing & super page', async () => {
    await InvestingAndSuperPage.openBusinessPage()
    await BusinessPage.checkHeaderAndFooter()
    await expect(browser).toHaveTitleContaining('Business Banking')
    await expect(browser).toHaveUrlContaining('business')
    await expect(BusinessPage.titleOnPage).toHaveText('Business banking')
  })

  it('should click on Institutional tab from the Business page', async () => {
    await BusinessPage.openInstitutionalPage()
    await InstitutionalPage.checkHeaderAndFooter()
    await expect(browser).toHaveTitle('Institutional - CommBank')
    await expect(browser).toHaveUrlContaining('institutional')
    await expect(InstitutionalPage.titleOnPage).toHaveText('Institutional banking and markets')
  })
})
