import Page from './Page'

class HomeLoansPage extends Page {
  get insuraneTab () { return $('.commbank-list > li:nth-child(5)') }

  async openInsurancePage () {
    await (await this.insuraneTab).click()
  }
}

export default new HomeLoansPage()
