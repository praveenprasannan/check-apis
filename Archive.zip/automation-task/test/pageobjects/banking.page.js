import Page from './Page'

class BankingPage extends Page {
  get homeLoansTab () { return $('.commbank-list > li:nth-child(4)') }

  async openHomeLoansPage () {
    await (await this.homeLoansTab).click()
  }
}

export default new BankingPage()
