import Page from './Page'

class InstitutionalPage extends Page {

}

export default new InstitutionalPage()
