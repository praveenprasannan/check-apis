import Page from './Page'

class BusinessPage extends Page {
  get institutionalTab () { return $('.commbank-list > li:nth-child(8)') }

  async openInstitutionalPage () {
    await (await this.institutionalTab).click()
  }
}

export default new BusinessPage()
