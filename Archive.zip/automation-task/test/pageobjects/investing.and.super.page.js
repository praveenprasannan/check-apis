import Page from './Page'
class InvestingAndSuperPage extends Page {
  get businessTab () { return $('.commbank-list > li:nth-child(7)') }

  async openBusinessPage () {
    await (await this.businessTab).click()
  }
}

export default new InvestingAndSuperPage()
