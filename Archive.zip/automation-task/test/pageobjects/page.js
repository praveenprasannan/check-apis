/**
* main page object containing all methods, selectors and functionality
* that is shared across all page objects
*/
export default class Page {
  // Page elements
  get titleOnPage () { return $('.banner-content-panel h1') }

  get pageHeader () { return $('.commbank-header') }

  get pageFooter () { return $('.footer-module') }

  /**
  * Opens a sub page of the page
  * @returns the url
  */
  open () {
    // browser.setWindowSize(978, 750)
    browser.setWindowSize(1400, 750)
    return browser.url('')
  }

  async checkHeaderAndFooter () {
    await expect(this.pageHeader).toBeExisting()
    await expect(this.pageFooter).toBeExisting()
  }
}
