import Page from './page'

class HomePage extends Page {
  get bankingTab () { return $('.commbank-list > li:nth-child(3)') }

  get desktopImage () { return $('.banner-image > img') }

  async openBankingPage () {
    await (await this.bankingTab).click()
  }
}

export default new HomePage()
