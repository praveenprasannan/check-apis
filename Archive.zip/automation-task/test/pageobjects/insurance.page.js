import Page from './Page'

class InsurancePage extends Page {
  get investingAndSuperTab () { return $('.commbank-list > li:nth-child(6)') }

  async openInvestingAndSuperPage () {
    await (await this.investingAndSuperTab).click()
  }
}

export default new InsurancePage()
