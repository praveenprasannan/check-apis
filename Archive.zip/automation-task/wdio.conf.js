export const config = {
  baseUrl: 'https://www.commbank.com.au/',
  runner: 'local',

  specs: [
    './test/specs/**/*.js'
  ],

  capabilities: [
    {
      maxInstances: 5,
      browserName: 'chrome',
      acceptInsecureCerts: true
    },
    {
      maxInstances: 5,
      browserName: 'firefox'
    }
  ],

  logLevel: 'error',
  bail: 0,
  waitforTimeout: 10000,
  connectionRetryTimeout: 120000,
  connectionRetryCount: 3,

  services: [
    [
      'chromedriver', {
        args: ['--enable-logging'],
        outputDir: './logs'
      }
    ],
    [
      'geckodriver', {
        args: ['--log=info'],
        logs: './logs'
      }
    ]
  ],

  reporters: [
    'spec',
    [
      'allure', {
        outputDir: 'wdio-report'
      }
    ]
  ],

  framework: 'mocha',
  mochaOpts: {
    require: ['@babel/register'],
    ui: 'bdd',
    timeout: 60000
  }
}
